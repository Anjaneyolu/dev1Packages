# Appian DevOps Quick Start - Applications

The Appian DevOps Quick Start is designed to be organized in single or groups of non-shared applications. There should be only one folder for every application or group of applications that are intended to function as one single application. 

The applications within the group should not be shared across other applications. In the case of shared applications, they should have their own folder and should not be apart of another application's folder. 

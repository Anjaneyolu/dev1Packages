# Appian DevOps Quick Start - DevOps Setup

This folder contains the configuration properties for the Automated Deployment Manager (ADM) and FitNesse For Appian (F4A). Within each folder are the respective property files needed for the Quick Start pipeline. In addition, the F4A folder also contains the whole set of customer test_suites needed to run the appropriate FitNesse tests. 
